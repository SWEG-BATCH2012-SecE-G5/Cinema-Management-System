#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>

struct Customer {
    std::string name;
    int age, id;
};

#endif // CUSTOMER_H