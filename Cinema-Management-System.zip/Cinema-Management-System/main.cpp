/**
 * SecE-SWEG2012Batch-G5
 * 
 * Group Members
 * 1. Milkaai Getachew 0478/12
 * 2. Naol Tamrat 0512/12
 * 3. Tselote Yonas 1052/12
 * 4. Wengelawit Getachew 1054/12
 * 5. Yohannes Kassa 1063/12
 *  
 *  Made to assist Cinema managers, this program
 *  keeps records of movies that can be watched in
 *  the cinema. It also holds customer databases
 *  inside to check for age verification.
 *  lastly, it manages the cinema hall slots for 
 *  the day, where one can add movies into it and add
 *  or cancel seat reservations for said slot.
 */
#include "include/MainMenu.h"

int main()
{
    mainMenu();
}